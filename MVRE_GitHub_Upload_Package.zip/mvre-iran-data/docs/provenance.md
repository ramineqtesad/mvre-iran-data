# Data provenance and replication boundary

The data files are exported without numeric rounding from the project workbooks identified by SHA-256 in `provenance.json`. These are **harmonized research inputs**, not copies of original provider downloads.

- Architecture A is the 17-row complete-case matrix for 2005–2021. All 340 indicator cells are present. No missing values were filled during construction of this matrix.
- F01 is a native overlapping three-year undernourishment measure assigned to the central year. It is not an independent annual observation. Its native periods are preserved in `f01_native_period_mapping.csv`.
- Architecture B contains the 15 matched windows for 2006–2020. Annual inputs were averaged over t−1, t, t+1, before subsequent transformations; F01 was not smoothed again.
- The dictionary is the archived Stage 7-A metadata snapshot from 2026-10-02. Its pending or partial lineage fields are retained as documented, rather than filled from memory. Some units and exact source codes still require original-source archival verification.
- The transformed, direction-aligned anchors are the frozen Architecture A anchors recorded in Stage 7-C. They are not refitted to new data and normalized scores are not clipped.
- Source families include FAO/FAOSTAT, World Bank/WDI, UNSD and UNCTAD, with WHO, ILO and IMF upstream where documented. Provider-generated model estimates can occur in the underlying series.
- This package does not claim full recovery of the original download archive. Original retrieval dates and complete source files were not recovered for every variable.

The Python code in this release was newly written on 2026-10-12. It reproduces the documented baseline calculation and the candidate boundary; it is **not the recovered original Monte Carlo, bootstrap or recovery code**. Those original scripts and complete aggregation settings are not included. Reported scenario frequencies must not be read as actual crisis probabilities.

The candidate boundary is a within-sample numerical partition. It is not an independently validated social adequacy floor or a structural collapse threshold. A high aggregate score need not imply that every dimension exceeds a separately defined essential-service minimum.

## Data rights

Original third-party data remain subject to their providers’ terms. The code license applies only to the new code. No blanket license or redistribution authorization is asserted for all source-provider data.
