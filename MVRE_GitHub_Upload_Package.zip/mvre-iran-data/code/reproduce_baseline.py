"""Reproduce documented MVRE baseline from harmonized inputs. Python stdlib only."""
from pathlib import Path
import csv
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[1]

def read_csv(name):
    with (ROOT / 'data' / name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def write_csv(name, columns, rows):
    with (ROOT / 'data' / name).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

def candidate_boundary(values, minimum_group_size=4):
    candidates = sorted(set(values))
    accepted = []
    for left, right in zip(candidates, candidates[1:]):
        theta = (left + right) / 2
        low = [value for value in values if value <= theta]
        high = [value for value in values if value > theta]
        if min(len(low), len(high)) < minimum_group_size:
            continue
        score = sum((value - statistics.mean(low)) ** 2 for value in low)
        score += sum((value - statistics.mean(high)) ** 2 for value in high)
        accepted.append((score, theta))
    if not accepted:
        raise ValueError('No admissible boundary')
    return min(accepted)[1]

def main():
    source = read_csv('harmonized_input_A_2005_2021.csv')
    anchors = read_csv('frozen_transform_anchors.csv')
    dimensions = read_csv('dimension_map.csv')
    benchmark = {int(row['Year']): float(row['MVRE_Benchmark'])
                 for row in read_csv('benchmark_mvre.csv')}
    variables = [row['Variable'] for row in anchors]
    assert len(source) == 17 and len(variables) == 20 and len(dimensions) == 7
    assert [int(row['Year']) for row in source] == list(range(2005, 2022))
    normalized, results = [], []
    for row in source:
        year = int(row['Year'])
        record = {'Year': year}
        for rule in anchors:
            variable = rule['Variable']
            value = float(row[variable])
            if not math.isfinite(value):
                raise ValueError(f'Invalid input: {year} {variable}')
            if rule['Transform'] == 'ln(x)':
                if value <= 0:
                    raise ValueError(f'Log input must be positive: {year} {variable}')
                value = math.log(value)
            if rule['Direction Alignment'].startswith('Adverse'):
                value = -value
            lo, hi = float(rule['A_Min Aligned']), float(rule['A_Max Aligned'])
            if hi <= lo:
                raise ValueError(f'Invalid anchor: {variable}')
            record[variable] = (value - lo) / (hi - lo)  # no clipping
        normalized.append(record)
        result = {'Year': year}
        for dimension in dimensions:
            members = dimension['Core Indicators'].split(',')
            assert len(members) == int(dimension['K'])
            result[dimension['Dimension']] = statistics.mean(record[key] for key in members)
        result['MVRE'] = statistics.mean(result[dimension['Dimension']] for dimension in dimensions)
        results.append(result)
    theta = candidate_boundary([row['MVRE'] for row in results])
    for result in results:
        result['candidate_boundary'] = theta
        result['classification'] = 'lower' if result['MVRE'] <= theta else 'upper'
    differences = [abs(row['MVRE'] - benchmark[row['Year']]) for row in results]
    if max(differences) > 1e-9:
        raise AssertionError('Baseline benchmark mismatch')
    lower = sum(row['classification'] == 'lower' for row in results)
    assert lower == 9 and len(results) - lower == 8
    write_csv('normalized_A_2005_2021.csv', ['Year'] + variables, normalized)
    write_csv('dimension_scores_and_mvre.csv', list(results[0]), results)
    report = {
        'scope': 'New baseline reconstruction, not full simulation replication',
        'rows': len(source), 'indicators': len(variables), 'nonmissing_cells': 340,
        'log_transforms': sum(row['Transform'] == 'ln(x)' for row in anchors),
        'adverse_sign_reversals': sum(row['Direction Alignment'].startswith('Adverse') for row in anchors),
        'maximum_absolute_mvre_difference': max(differences), 'tolerance': 1e-9,
        'candidate_boundary': theta, 'lower_years': lower, 'upper_years': len(results) - lower,
        'mean_mvre': statistics.mean(row['MVRE'] for row in results),
        'sample_standard_deviation': statistics.stdev(row['MVRE'] for row in results),
        'benchmark_validation': 'PASS'
    }
    (ROOT / 'docs' / 'validation_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
